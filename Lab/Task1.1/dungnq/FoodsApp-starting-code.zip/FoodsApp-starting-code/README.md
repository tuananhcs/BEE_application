# FoodsApp-starting-code


![alt text](https://github.com/alexander-kn/FoodsApp-starting-code/blob/master/Screenshot1.jpg)
![alt text](https://github.com/alexander-kn/FoodsApp-starting-code/blob/master/Screenshot2.jpg)

